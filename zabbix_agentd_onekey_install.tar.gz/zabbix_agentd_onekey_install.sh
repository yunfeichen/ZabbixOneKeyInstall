#!/bin/bash
#Settings section
ZABBIX_SERVER_IP=192.168.174.147

#Install section
groupadd zabbix
useradd -g zabbix zabbix
tar xvf zabbix-3.2.3.tar.gz
cd zabbix-3.2.3
./configure --prefix=/usr/local/zabbix_agent/ --enable-agent
make &&make install
sed -i "s/Server=127.0.0.1/Server=$ZABBIX_SERVER_IP/g" /usr/local/zabbix_agent/etc/zabbix_agentd.conf 
scp -rp misc/init.d/fedora/core/zabbix_agentd /etc/init.d/
chmod  +x /etc/init.d/zabbix_agentd
sed -i 's/BASEDIR=\/usr\/local/BASEDIR=\/usr\/local\/zabbix_agent/g'  /etc/init.d/zabbix_agentd 
/etc/init.d/zabbix_agentd start
chkconfig zabbix_agentd on
echo "export PATH=/etc/init.d:$PATH:." >> /etc/profile
export PATH=/etc/init.d:$PATH:.
~
